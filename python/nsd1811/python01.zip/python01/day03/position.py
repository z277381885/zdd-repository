import sys

print(sys.argv)  # argv是sys模块中的列表，将位置参数存到该列表中
