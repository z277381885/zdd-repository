hi = 'hello world!'

def pstar(n=30):
    print('*' * n)

if __name__ == '__main__':
    pstar()
    pstar(40)
