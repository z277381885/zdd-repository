import shutil

shutil.copyfileobj()
shutil.copy()
