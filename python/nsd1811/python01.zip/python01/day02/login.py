username = input('username: ')
print('Welcome', username)
print('Welcome ' + username)
