result = 0
counter = 1

while counter <= 100:
    result += counter
    counter += 1

print(result)
