# print('Hello World!')
#
# if 3 > 0:
#     print('yes')
#     print('ok')

# print('Hello World')
# print('Hello', 'World!', 'hao', 123)  # 默认打印的各项之间用空格分隔
# print('Hello', 'World!', 'hao', 123, sep='***')  # 打印各项间用***分开
# print('Hello' + 'World' + '!')   # 字符串拼接

num = input('number: ')
print(num)
